$ make clean
$ make
$ echo -e "bar\nbar\nbaz\nfoo\nfoo\nfoo" | ./cuniq