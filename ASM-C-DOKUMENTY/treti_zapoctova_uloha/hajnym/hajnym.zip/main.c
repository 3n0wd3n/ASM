#include <stdio.h>

void main_asm();

int main(){
	main_asm();
	return 0;
}
